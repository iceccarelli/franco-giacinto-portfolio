import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Phone } from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { company } from "@/data/company";
import { services } from "@/data/services";

const mega = [
  {
    heading: "Floors",
    items: [
      { label: "Installation", to: "/services/$slug" as const, slug: "hardwood-installation" },
      { label: "Sanding & refinishing", to: "/services/$slug" as const, slug: "sanding-refinishing" },
      { label: "Repairs", to: "/services/$slug" as const, slug: "hardwood-repairs" },
      { label: "Decks", to: "/services/$slug" as const, slug: "hardwood-decks" },
    ],
  },
  {
    heading: "Stairs & rails",
    items: [
      { label: "Stair studio", to: "/stairs" as const },
      { label: "Hardwood stairs", to: "/services/$slug" as const, slug: "hardwood-stairs" },
      { label: "Hardwood railings", to: "/services/$slug" as const, slug: "hardwood-railings" },
    ],
  },
  {
    heading: "Specify",
    items: [
      { label: "Showroom", to: "/showroom" as const },
      { label: "Estimator", to: "/estimate" as const },
      { label: "Hardwood vs vinyl", to: "/compare" as const },
      { label: "Process", to: "/process" as const },
    ],
  },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:h-[4.25rem] sm:px-6">
        <Logo />
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          <div className="group relative">
            <Link
              to="/services"
              className="inline-flex h-11 items-center rounded-md px-3 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
            >
              Services
            </Link>
            <div className="invisible absolute top-full left-0 pt-2 opacity-0 transition-[opacity] duration-150 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
              <div className="grid w-[38rem] grid-cols-3 gap-6 rounded-xl bg-surface p-6 shadow-[var(--shadow-card)]">
                {mega.map((col) => (
                  <div key={col.heading}>
                    <p className="text-xs tracking-[0.14em] text-muted uppercase">{col.heading}</p>
                    <ul className="mt-2 space-y-1">
                      {col.items.map((item) => (
                        <li key={item.label}>
                          {"slug" in item && item.slug ? (
                            <Link
                              to="/services/$slug"
                              params={{ slug: item.slug }}
                              className="block rounded-md px-2 py-1.5 text-sm hover:bg-bg-warm"
                            >
                              {item.label}
                            </Link>
                          ) : (
                            <Link
                              to={item.to}
                              className="block rounded-md px-2 py-1.5 text-sm hover:bg-bg-warm"
                            >
                              {item.label}
                            </Link>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <Link
            to="/stairs"
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            Stairs
          </Link>
          <Link
            to="/services/$slug"
            params={{ slug: "hardwood-railings" }}
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            Railings
          </Link>
          <Link
            to="/showroom"
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            Showroom
          </Link>
          <Link
            to="/portfolio"
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            Work
          </Link>
          <Link
            to="/areas"
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            Areas
          </Link>
          <Link
            to="/about"
            className="rounded-md px-3 py-2 text-sm font-medium text-fg/80 transition-colors hover:bg-bg-warm hover:text-fg"
          >
            About
          </Link>
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <a
            href={`tel:${company.phone}`}
            className="inline-flex h-11 items-center gap-2 px-2 text-sm font-medium text-primary"
          >
            <Phone className="size-4" />
            {company.phoneDisplay}
          </a>
          <Button asChild>
            <Link to="/estimate">Free estimate</Link>
          </Button>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="lg:hidden" aria-label="Open menu">
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <Logo className="mb-8" />
            <nav className="flex flex-col gap-1" aria-label="Mobile">
              {[
                { label: "Services", to: "/services" as const },
                { label: "Stair studio", to: "/stairs" as const },
                { label: "Showroom", to: "/showroom" as const },
                { label: "Work", to: "/portfolio" as const },
                { label: "Areas", to: "/areas" as const },
                { label: "Guides", to: "/guides" as const },
                { label: "About", to: "/about" as const },
                { label: "Trade", to: "/trade" as const },
                { label: "Contact", to: "/contact" as const },
              ].map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="rounded-md px-3 py-3 text-base font-medium hover:bg-bg-warm"
                >
                  {item.label}
                </Link>
              ))}
              {services.slice(0, 6).map((child) => (
                <Link
                  key={child.slug}
                  to="/services/$slug"
                  params={{ slug: child.slug }}
                  onClick={() => setOpen(false)}
                  className="rounded-md px-3 py-2 pl-5 text-sm text-muted hover:bg-bg-warm hover:text-fg"
                >
                  {child.shortName}
                </Link>
              ))}
            </nav>
            <div className="mt-auto flex flex-col gap-2 pt-8">
              <Button asChild>
                <Link to="/estimate" onClick={() => setOpen(false)}>
                  Free estimate
                </Link>
              </Button>
              <Button asChild variant="outline">
                <a href={`tel:${company.phone}`}>Call {company.phoneDisplay}</a>
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
