import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { JsonLd } from "@/components/json-ld";
import { QuoteForm } from "@/components/estimate/quote-form";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { projects } from "@/data/projects";
import { getService, services } from "@/data/services";
import { breadcrumbLd, faqLd, pageTitle, serviceLd } from "@/lib/seo";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: pageTitle(
          `${loaderData?.service.name ?? "Service"} Toronto & GTA`,
        ),
      },
      {
        name: "description",
        content: loaderData?.service.summary ?? "",
      },
    ],
  }),
  component: ServicePage,
});

const categoryMap: Record<string, (typeof projects)[number]["category"]> = {
  "hardwood-installation": "install",
  "hardwood-stairs": "stairs",
  "hardwood-railings": "stairs",
  "sanding-refinishing": "refinish",
  "hardwood-repairs": "repair",
  "hardwood-decks": "deck",
  "custom-inlays": "custom",
  "commercial-hardwood": "commercial",
};

function ServicePage() {
  const { service } = Route.useLoaderData();
  const others = services.filter((s) => s.slug !== service.slug).slice(0, 3);
  const related = projects
    .filter((p) => p.category === categoryMap[service.slug])
    .slice(0, 2);

  return (
    <>
      <JsonLd
        data={breadcrumbLd([
          { name: "Home", path: "/" },
          { name: "Services", path: "/services" },
          { name: service.name, path: `/services/${service.slug}` },
        ])}
      />
      <JsonLd data={serviceLd(service)} />
      <JsonLd data={faqLd(service.faqs)} />
      <section className="border-b border-border bg-bg-warm">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 sm:px-6 lg:grid-cols-2">
          <div>
            <p className="text-xs tracking-[0.18em] text-accent uppercase">
              {service.eyebrow}
            </p>
            <h1 className="mt-3 font-display text-4xl leading-[1.08] sm:text-5xl">
              {service.headline}
            </h1>
            <p className="mt-4 text-lg text-muted">{service.summary}</p>
            <p className="mt-4 text-sm font-medium text-primary">
              {service.priceFrom} · {service.duration}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/estimate">Estimate this work</Link>
              </Button>
              {service.slug === "hardwood-stairs" && (
                <Button asChild variant="outline">
                  <Link to="/stairs">Stair studio</Link>
                </Button>
              )}
              <Button asChild variant="outline">
                <Link to="/portfolio">See related projects</Link>
              </Button>
            </div>
          </div>
          <img
            src={service.image}
            alt={service.imageAlt}
            className="aspect-[4/3] w-full rounded-xl object-cover shadow-[var(--shadow-card)]"
          />
        </div>
      </section>
      <div className="mx-auto grid max-w-6xl gap-12 px-4 py-12 sm:px-6 lg:grid-cols-[1.3fr_0.7fr]">
        <article>
          <ul className="space-y-3">
            {service.bullets.map((b) => (
              <li key={b} className="flex gap-3">
                <Check className="mt-1 size-4 shrink-0 text-accent" />
                <span>{b}</span>
              </li>
            ))}
          </ul>
          <div className="mt-8 space-y-4 text-muted">
            {service.body.map((p) => (
              <p key={p.slice(0, 24)}>{p}</p>
            ))}
          </div>
          {related.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-2xl">Related GTA work</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {related.map((p) => (
                  <article key={p.slug} className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-card)]">
                    <img src={p.image} alt={p.imageAlt} className="aspect-[16/10] w-full object-cover" />
                    <div className="p-4">
                      <h3 className="font-display text-lg">{p.title}</h3>
                      <p className="mt-1 text-sm text-muted">{p.summary}</p>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}
          {service.faqs.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-2xl">Questions about {service.shortName.toLowerCase()}</h2>
              <Accordion type="single" collapsible className="mt-4">
                {service.faqs.map((f) => (
                  <AccordionItem key={f.q} value={f.q}>
                    <AccordionTrigger>{f.q}</AccordionTrigger>
                    <AccordionContent>{f.a}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          )}
        </article>
        <aside className="h-fit rounded-xl bg-surface p-6 shadow-[var(--shadow-card)]">
          <h2 className="font-display text-2xl">Book the site visit</h2>
          <p className="mt-2 mb-4 text-sm text-muted">
            Free inside the GTA for qualified {service.shortName.toLowerCase()} work.
          </p>
          <QuoteForm defaultService={service.slug.includes("stair") ? "stairs" : service.slug.includes("rail") ? "railings" : service.slug.includes("refin") ? "refinish" : service.slug.includes("repair") ? "repair" : service.slug.includes("deck") ? "deck" : "install"} />
        </aside>
      </div>
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <h2 className="font-display text-2xl">Also in the shop</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {others.map((s) => (
              <Link
                key={s.slug}
                to="/services/$slug"
                params={{ slug: s.slug }}
                className="rounded-xl bg-surface p-5 shadow-[var(--shadow-card)]"
              >
                <h3 className="font-display text-xl">{s.shortName}</h3>
                <p className="mt-2 text-sm text-muted">{s.summary}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
