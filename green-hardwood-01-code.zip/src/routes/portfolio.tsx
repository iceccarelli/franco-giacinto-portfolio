import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BeforeAfter } from "@/components/before-after";
import { PageHero } from "@/components/page-hero";
import { Badge } from "@/components/ui/badge";
import { projectFilters, projects } from "@/data/projects";
import { pageTitle } from "@/lib/seo";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: pageTitle("Hardwood Portfolio") },
      {
        name: "description",
        content:
          "Hardwood installation, refinishing, custom stairs, railings, repairs, and decks completed across Toronto and the Greater Toronto Area.",
      },
    ],
  }),
  component: PortfolioPage,
});

function PortfolioPage() {
  const [filter, setFilter] = useState<(typeof projectFilters)[number]["id"]>("all");
  const visible =
    filter === "all" ? projects : projects.filter((p) => p.category === filter);

  return (
    <>
      <PageHero
        kicker="Work"
        title="Floors, stairs, and railings you can inspect in person."
        lede="A working selection from Forest Hill restorations, Vaughan new builds, Oakville estates, and occupied GTA condos."
      />
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap gap-2">
          {projectFilters.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "h-11 rounded-full px-4 text-sm",
                filter === f.id
                  ? "bg-primary text-primary-fg"
                  : "border border-border bg-surface text-fg hover:bg-bg-warm",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {visible.map((p) => (
            <article key={p.slug} className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-card)]">
              {p.before && p.after ? (
                <BeforeAfter
                  before={p.before}
                  after={p.after}
                  beforeAlt={`Before: ${p.title}`}
                  afterAlt={p.imageAlt}
                />
              ) : (
                <img src={p.image} alt={p.imageAlt} className="aspect-[4/3] w-full object-cover" />
              )}
              <div className="p-6">
                <div className="flex flex-wrap gap-2">
                  <Badge>{p.location}</Badge>
                  <Badge>{p.type}</Badge>
                </div>
                <h2 className="mt-3 font-display text-2xl">{p.title}</h2>
                <p className="mt-2 text-muted">{p.details}</p>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {p.specs.map((spec) => (
                    <li
                      key={spec}
                      className="rounded-full bg-bg-warm px-3 py-1 text-xs text-muted"
                    >
                      {spec}
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </>
  );
}
