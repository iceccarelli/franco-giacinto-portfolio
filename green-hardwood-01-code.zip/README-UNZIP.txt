GREEN HARDWOOD — PART 1 of 3  (code)

Unzip this archive at the repository root (the folder that already has package.json
or that will become the Green Hardwood site). Unzip parts 2 and 3 into the SAME root.

  green-hardwood-01-code.zip     ← you are here   src/, package.json, public SEO files
  green-hardwood-02-images.zip   → public/images/*.jpg
  green-hardwood-03-video.zip    → public/videos/stairs-hero.mp4

Order does not matter. Do not unzip into a subfolder named after the zip.
Do not commit the .zip files themselves.

After all three are extracted:

  npm install
  npm run dev

Do not add .vercel/, artifacts/, screenshots/, or .grok/ — those were sandbox
build cache and are intentionally left out of this kit.
