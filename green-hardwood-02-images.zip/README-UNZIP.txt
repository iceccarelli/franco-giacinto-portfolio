GREEN HARDWOOD — PART 2 of 3  (photographs)

Unzip at the same repository root as part 1.

This creates public/images/*.jpg — the files src/data/services.ts and
src/data/projects.ts already point at. Overwrite if those filenames exist.

  after-refinished.jpg
  before-worn.jpg
  hero-living.jpg
  hero-stairs.jpg
  project-etobicoke.jpg
  project-forest-hill.jpg
  project-herringbone.jpg
  project-inlay.jpg
  project-oakville-stairs.jpg
  railing-join.jpg
  service-deck.jpg
  service-install.jpg
  service-railings.jpg
  service-refinish.jpg
  service-repair.jpg
  service-stairs.jpg
  species-board.jpg
  species-samples.jpg
  stair-studio.jpg
  workshop.jpg
