# Prompt to paste to the coding agent

Copy everything below the line.

---

You are upgrading the Next.js 14 App Router TypeScript repo `franco-giacinto-portfolio` into the production website for **Green Hardwood**, a GTA / Ontario company whose money niche is:

1. Hardwood installation (solid + engineered, nail-down / glue-down / floating)
2. Hardwood stairs (treads, risers, stringers, landings)
3. Hardwood railings (handrails, newels, pickets, volutes)
4. Then the full trade: sanding, finishing, refinishing, repairs, custom patterns, decks if offered

## Non-negotiable brand rules

- Public brand name is **Green Hardwood**. Not FG Hardwood. Not Franco Giacinto Portfolio. Franco can appear as Master Craftsman / Founder, never as the company name in the H1 or title tag.
- Kill the placeholder phone `416-555-0199` until a real number exists. Do not ship fake NAP data. Fake NAP destroys local SEO and trust.
- Domain goal: `greenhardwood.ca` (or the real owned domain). Vercel preview URL is not the brand.
- Do not present generated images as named completed jobs (no “Forest Hill Heritage Restoration” photo unless that photo is real).

## Media already added

A media pack was unzipped into `public/`. Wire these exact paths with `next/image`. Do not invent new filenames.

| Path | Use |
|---|---|
| `/images/hero/01-hero-wide-plank-white-oak-living-room.jpg` | Homepage LCP hero |
| `/images/services/02-service-hardwood-installation-nail-down.jpg` | Installation service |
| `/images/stairs/03-service-custom-hardwood-staircase.jpg` | Stairs service + homepage feature |
| `/images/stairs/04-service-hardwood-railing-handrail.jpg` | Railings service |
| `/images/process/05-process-dust-contained-sanding.jpg` | Sanding / process |
| `/images/process/06-process-stain-and-finish.jpg` | Finishing / process |
| `/images/process/07-process-refinish-before-after.jpg` | Refinishing |
| `/images/portfolio/08-portfolio-herringbone-white-oak.jpg` | Custom / pattern work |
| `/images/services/09-service-hardwood-deck.jpg` | Decks (only if service is real) |
| `/images/brand/10-og-green-hardwood-brand.jpg` | Brand still |
| `/og-image.jpg` | Default Open Graph image |

Every `<Image>` needs width/height or fill + sizes, `alt` from `docs/MANIFEST.csv`, and the homepage hero must be `priority`.

Add a blur placeholder or solid walnut color placeholder so layout does not jump.

## Information architecture (rebuild this)

Replace the single personal-portfolio page with real routes:

- `/` Home
- `/services` Services index
- `/services/hardwood-installation`
- `/services/hardwood-stairs`
- `/services/hardwood-railings`
- `/services/hardwood-sanding`
- `/services/hardwood-finishing`
- `/services/hardwood-refinishing`
- `/services/hardwood-repair`
- `/services/hardwood-decks` (only if offered)
- `/work` Real project index (empty state until real photos exist)
- `/process`
- `/areas` Toronto, Mississauga, Oakville, Vaughan, Markham, Richmond Hill, Etobicoke, Brampton, Burlington, Scarborough — one section each, not a spam city ticker
- `/about`
- `/contact`

Add `sitemap.ts`, `robots.ts`, canonical URLs, and `app/layout.tsx` metadata:

Title pattern: `Hardwood Stairs Toronto | Green Hardwood`
Description: one sentence, service + city + proof + CTA.
OG image: `/og-image.jpg`

JSON-LD:

- Organization + LocalBusiness (FlooringContractor)
- Service schema per money page
- FAQPage on stairs, installation, refinishing
- BreadcrumbList
- Real AggregateRating only if reviews are real and hosted

## Copy rules

- Lead with stairs + installation. That is the wedge.
- No emoji section icons.
- No fake metrics (1200+ floors, 98% satisfaction, <1% callback) unless there is a source.
- No fake certifications (NWFA, Bona) unless certificates exist.
- No fake equipment list.
- No fake Instagram if it is not the business account.
- Write like a trades company that wants booked jobs, not a designer portfolio.

## Conversion

Sticky header: Call / Text / Book estimate.
Contact form fields: name, phone, email, city, service (stairs / install / refinish / repair / railing / deck), sq ft or number of steps, photo upload, timeline.
After submit: thank-you page + event `generate_lead`.
Click-to-call on mobile.

## Technical

- Keep Next.js App Router + TypeScript strict.
- Use `next/image` for all 10 photos.
- Add `next/font` for a serious pair (e.g. Newsreader or Fraunces + Inter). Drop the generic Inter-only look if possible.
- Pure CSS is fine. Kill canvas “visualizers” from the first viewport. They waste LCP and confuse homeowners.
- Lighthouse targets: LCP < 2.5s, CLS < 0.1, accessible names on all controls.
- 404 page that routes to Stairs, Installation, Refinishing.

## Do this first, in order

1. Merge brand name to Green Hardwood in layout, header, footer, JSON-LD, README.
2. Wire the 10 images with next/image and correct alts.
3. Split money pages for stairs, installation, railings.
4. Remove fake NAP, fake stats, fake certs.
5. Add sitemap, robots, OG, canonical.
6. Build the estimate form.
7. Leave a clearly labeled “replace with job-site photo” comment on every generated image.

Do not restyle for vanity. Restyle so a Forest Hill or Oakville homeowner trusts the company in 8 seconds and books a site visit.
---
