# Green Hardwood — Media Pack v1

Drop-in image pack for the Next.js App Router repo  
`iceccarelli/franco-giacinto-portfolio`

These 10 files are **layout and SEO scaffolding**, not proof of completed Green Hardwood jobs.  
Replace them with real job-site photography before presenting any image as a Green Hardwood project.

## Install into the repo

From the repository root:

```bash
# unzip so public/ merges with the existing public/ folder
unzip green-hardwood-media-pack.zip
```

Expected result:

```
public/
  og-image.jpg
  images/
    hero/
    services/
    stairs/
    process/
    portfolio/
    brand/
  portrait.jpg          # already in the repo — keep until a real brand portrait exists
```

In Next.js, files under `public/` are served from `/`.

Examples:

- `/images/hero/01-hero-wide-plank-white-oak-living-room.jpg`
- `/images/stairs/03-service-custom-hardwood-staircase.jpg`
- `/og-image.jpg`

## Naming convention

```
NN-role-subject-descriptor.jpg
```

- `NN` = intended priority order
- `role` = hero | service | process | portfolio | og
- kebab-case only
- no spaces, no uppercase, no dates in the filename

## Honesty rule

Alt text and captions must say these are representative hardwood work, not named Green Hardwood projects, until real photos replace them.

See `docs/MANIFEST.csv` and `docs/AGENT-PROMPT.md`.
